package com.lslauncher

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var store: ModStore
    private var onMods = false
    private var message: Pair<String, Boolean>? = null

    private val BG = Color.parseColor("#0B0614")
    private val NEON = Color.parseColor("#B026FF")
    private val PANEL = Color.parseColor("#160B26")
    private val REQ_PICK = 42

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = ModStore(this)
        showMain()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun btn(text: String, size: Float = 20f, color: Int = NEON, click: () -> Unit) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(PANEL); setStroke(dp(3), color); cornerRadius = dp(6).toFloat()
            }
            setOnClickListener { click() }
        }

    private fun label(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(20), dp(32), dp(20), dp(20))
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    // ---------- Tela principal ----------
    private fun showMain() {
        onMods = false
        val r = root()
        r.addView(label("LS LAUNCHER", 30f, NEON).apply { gravity = Gravity.CENTER }, lp())
        val mods = store.list()
        val on = mods.count { it.enabled }
        r.addView(label("${mods.size} MODS IMPORTADOS", 15f, Color.LTGRAY).apply { gravity = Gravity.CENTER }, lp(24))
        r.addView(label("$on MODS LIGADOS", 15f, Color.parseColor("#39FF14")).apply { gravity = Gravity.CENTER }, lp(4))
        r.addView(label("${mods.size - on} MODS DESLIGADOS", 15f, Color.parseColor("#FF5577")).apply { gravity = Gravity.CENTER }, lp(4))
        r.addView(btn("▶  JOGAR", 26f) { play() }, lp(40))
        r.addView(btn("✚  MODS", 26f) { showMods() }, lp(16))
        setContentView(r)
    }

    // ---------- Tela de mods ----------
    private fun showMods() {
        onMods = true
        val r = root()
        r.addView(label("MODS", 28f, NEON).apply { gravity = Gravity.CENTER }, lp())
        r.addView(btn("📁 IMPORTAR MODS\n(Arquivos .ls)", 18f) { pick() }, lp(16))
        message?.let { (t, ok) ->
            r.addView(label(t, 15f, if (ok) Color.parseColor("#39FF14") else Color.parseColor("#FF5577"))
                .apply { gravity = Gravity.CENTER }, lp(12))
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        store.list().forEach { m ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(PANEL); setStroke(dp(2), if (m.enabled) Color.parseColor("#39FF14") else NEON)
                    cornerRadius = dp(6).toFloat()
                }
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(m.name, 16f))
            info.addView(label(if (m.enabled) "LIGADO" else "DESLIGADO", 13f,
                if (m.enabled) Color.parseColor("#39FF14") else Color.parseColor("#FF5577")))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(btn(if (m.enabled) "DESLIGAR" else "LIGAR", 12f) { store.toggle(m.id); showMods() })
            row.addView(btn("APAGAR", 12f, Color.parseColor("#FF3355")) { store.delete(m.id); showMods() },
                LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            list.addView(row, lp(10))
        }
        r.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        r.addView(btn("↩  SAIR", 18f) { message = null; showMain() }, lp(12))
        setContentView(r)
    }

    // ---------- Importação ----------
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != REQ_PICK || res != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        val name = displayName(uri)
        message = if (!name.endsWith(".ls", ignoreCase = true)) {
            "ERRO AO IMPORTAR: só aceita arquivos .ls" to false
        } else try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val err = store.import(name, bytes)
            if (err == null) "MOD IMPORTADO COM SUCESSO" to true else "ERRO AO IMPORTAR: $err" to false
        } catch (e: Exception) { "ERRO AO IMPORTAR: ${e.message}" to false }
        showMods()
    }

    private fun displayName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use {
            val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && idx >= 0) it.getString(idx) else null
        } ?: uri.lastPathSegment ?: ""

    // ---------- Jogar ----------
    private fun play() {
        val intent = packageManager.getLaunchIntentForPackage(Config.GAME_PACKAGE)
        if (intent == null) {
            Toast.makeText(this, "Jogo não instalado (${Config.GAME_PACKAGE})", Toast.LENGTH_LONG).show()
            return
        }
        val enabled = store.enabled()   // só os LIGADOS; desligados nunca são enviados
        if (enabled.isNotEmpty()) {
            val uris = enabled.map { Uri.parse("content://${Config.AUTHORITY}/mods/${it.id}") }
            intent.putStringArrayListExtra(Config.EXTRA_MODS, ArrayList(uris.map { it.toString() }))
            intent.putExtra(Config.EXTRA_COUNT, uris.size)
            val clip = ClipData.newRawUri("ls_mods", uris[0])
            uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
            intent.clipData = clip
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        // sem mods ligados: inicia o jogo normal, sem extras
        startActivity(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (onMods) { message = null; showMain() } else super.onBackPressed() }
}
