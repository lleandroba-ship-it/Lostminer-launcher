package com.lslauncher

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.FileNotFoundException

/**
 * Carregador de mods: expõe ao jogo apenas os mods LIGADOS.
 *  content://com.lslauncher.mods/mods        -> lista (id, name)
 *  content://com.lslauncher.mods/mods/<id>   -> conteúdo do .ls (só se estiver ligado)
 */
class ModsProvider : ContentProvider() {
    override fun onCreate() = true

    override fun query(u: Uri, p: Array<String>?, s: String?, a: Array<String>?, o: String?): Cursor {
        val c = MatrixCursor(arrayOf("id", "name"))
        ModStore(context!!).enabled().forEach { c.addRow(arrayOf(it.id, it.name)) }
        return c
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val id = uri.lastPathSegment ?: throw FileNotFoundException()
        val store = ModStore(context!!)
        if (store.enabled().none { it.id == id }) throw FileNotFoundException("mod desligado")
        return ParcelFileDescriptor.open(store.file(id), ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(u: Uri) = "application/octet-stream"
    override fun insert(u: Uri, v: ContentValues?): Uri? = null
    override fun delete(u: Uri, s: String?, a: Array<String>?) = 0
    override fun update(u: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
}
