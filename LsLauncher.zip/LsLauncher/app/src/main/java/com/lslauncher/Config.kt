package com.lslauncher

object Config {
    /** Pacote do jogo instalado no celular. TROQUE pelo pacote real (e também no <queries> do Manifest). */
    const val GAME_PACKAGE = "com.exemplo.jogo"

    const val AUTHORITY = "com.lslauncher.mods"
    const val EXTRA_MODS = "ls_mods_uris"   // lista de content:// URIs dos mods LIGADOS
    const val EXTRA_COUNT = "ls_mods_count"
    const val MAX_SIZE = 5 * 1024 * 1024
}
