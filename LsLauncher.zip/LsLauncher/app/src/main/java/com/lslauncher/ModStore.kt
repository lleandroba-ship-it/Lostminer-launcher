package com.lslauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.UUID

data class Mod(val id: String, val name: String, val enabled: Boolean)

/** Valida o conteúdo de um .ls antes de aceitar. Retorna null se OK, ou o motivo do erro. */
object LsValidator {
    fun validate(bytes: ByteArray): String? {
        if (bytes.isEmpty()) return "arquivo vazio"
        if (bytes.size > Config.MAX_SIZE) return "arquivo grande demais"
        val text = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: Exception) { return "conteúdo não é texto UTF-8 válido" }
        if (text.isBlank()) return "arquivo sem conteúdo"
        if (text.contains('\u0000')) return "conteúdo binário inválido"
        // Se você souber a estrutura exata do formato .ls, adicione as checagens aqui.
        return null
    }
}

/** Guarda mods (arquivos em filesDir/mods) e estado (SharedPreferences). Persiste após fechar. */
class ModStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "mods").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("mods", Context.MODE_PRIVATE)

    fun file(id: String) = File(dir, "$id.ls")

    fun list(): List<Mod> {
        val arr = JSONArray(prefs.getString("list", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Mod(o.getString("id"), o.getString("name"), o.getBoolean("enabled"))
        }.filter { file(it.id).exists() }
    }

    private fun save(l: List<Mod>) {
        val arr = JSONArray()
        l.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("enabled", it.enabled)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    /** Retorna null se OK, ou mensagem de erro. Mod inválido NUNCA é salvo. */
    fun import(name: String, bytes: ByteArray): String? {
        LsValidator.validate(bytes)?.let { return it }
        val id = UUID.randomUUID().toString()
        file(id).writeBytes(bytes)
        save(list() + Mod(id, name.removeSuffix(".ls"), false))
        return null
    }

    fun toggle(id: String) = save(list().map { if (it.id == id) it.copy(enabled = !it.enabled) else it })

    fun delete(id: String) { file(id).delete(); save(list().filter { it.id != id }) }

    fun enabled() = list().filter { it.enabled }
}
