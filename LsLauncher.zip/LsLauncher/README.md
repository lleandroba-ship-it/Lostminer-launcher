# LS Launcher
1. Edite `Config.GAME_PACKAGE` e o `<queries>` do AndroidManifest com o pacote real do jogo.
2. Envie para o GitHub (branch main). Actions > Build APK > Artifacts > LsLauncher-APK.
